﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimPlayerController : MonoBehaviour
{
    private Rigidbody2D RigBod;

    // Start is called before the first frame update
    void Start()
    {
        RigBod = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        MovementHandler();
    }

    private void MovementHandler()
    {
        RigBod.velocity = Vector2.left;
    }
}
