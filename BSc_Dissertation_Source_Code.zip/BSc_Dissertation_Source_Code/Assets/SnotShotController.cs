﻿using System.Runtime;
//using System.Threading.Tasks.Dataflow;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SnotShotController : MonoBehaviour
{
    public float SnotLifeTime;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SnotDelay()); //a coroutine is a function that has the ability to pause an execution and return control to Unity
    }

    // Update is called once per frame
    void Update()
    {

    }   

    IEnumerator SnotDelay()
    {
        yield return new WaitForSeconds(SnotLifeTime);
        Destroy(gameObject);
    }

    public void OnTriggerEnter2D(Collider2D col) 
    {
        // if (col.tag == "Enemy")
        // {
        //     col.gameObject.GetComponent<EnemyController>().Death();

        // }

        if (col.CompareTag("Enemy"))
        {
            DestroySnotShot();
            Debug.Log("BulletCollision");
        }
    }

    void DestroySnotShot()
    {
        Destroy(gameObject);
    }
}
