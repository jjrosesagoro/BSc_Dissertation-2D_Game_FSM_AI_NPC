﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene(2);
    }

     public void Instructions()
    {
        SceneManager.LoadScene(1);
    }

     public void BackBtn()
    {
        SceneManager.LoadScene(0);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    // Start is called before the first frame update
    void Start()
    {
        //GameObject.FindGameObjectWithTag("BackBtn").SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
